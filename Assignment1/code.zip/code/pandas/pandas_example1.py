import pandas as pd
import numpy as np
a = np.array(['a','b','c','d'])
s = pd.Series(a)
print s