import pandas as pd
arr=[[123,'Andrew',15],[456,'Mike',17],[789,'John',16]]
df = pd.DataFrame(arr,columns=['Student Id','Name','Age'])
print df