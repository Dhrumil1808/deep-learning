a=100
b=100 

if( a < b):
    print "a is less than b"
else:
    print " a is greater than b"   #logical error as it prints "a is greater than b" even though a=b