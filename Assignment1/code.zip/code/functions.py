def sum(a,b): # function to add two numbers
    c = a + b
    print c

sum(2,3)  