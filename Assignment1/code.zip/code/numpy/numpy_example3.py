import numpy as np 
first = np.array([[0.0,1.0,2.0],[6.0,7.0,8.0]]) 
second = np.array([1.0,2.0,3.0])  
   
print ' First Array'
print first

print 'Second Array'
print second

print 'resultant array'
print first + second
