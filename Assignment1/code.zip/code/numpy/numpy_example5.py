import numpy as np 
arr = np.array([0,30,45,60,90,120,135,150,180]) 
print 'Sine value of the angles' 
print np.sin(arr*np.pi/180) 
print 'Cosine values of the given angles' 
print np.cos(arr*np.pi/180) 
print 'Tangent values of given values' 
print np.tan(arr*np.pi/180) 