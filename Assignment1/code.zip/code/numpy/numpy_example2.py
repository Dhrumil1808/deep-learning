import numpy as np 
a = np.arange(24)  
print a
print a.shape

b = a.reshape(2,4,3)  #reshaped array
print b 