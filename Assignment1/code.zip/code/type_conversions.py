string = "100"
integer= int("100")  
bases=int(string,2) # converted the string to base 2
decimal= 3
decimal= float(integer)  #type casted from integer to float

print(integer)
print(decimal)
print(bases)