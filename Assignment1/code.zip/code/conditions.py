a=10;
if(a <10): #evaluated when input is less than 10
    print "a is less than 10"
elif( a ==10): #evaluated when input equals 10
    print "a is equal to 10"
else: #evaulated when input is greater than 10
    print "a is greater than 10"