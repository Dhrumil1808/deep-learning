class basic:
    def function(self):
        print ("this is called from a function")
        
object1=basic(); #object of class "basic" is created
object1.function()   #function called with the help of object